package com.example.demo.controller;

import com.example.demo.repo.FilmActorRepo;
import com.example.demo.repo.FilmRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "https://video-rush-front-end.web.app/")
@RestController
public class FilmActorController {

    @Autowired
    FilmActorRepo filmActorRepo;
}

package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class ActorID implements Serializable {

    private Integer filmId;

    private Integer actorId;
}

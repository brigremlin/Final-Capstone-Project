package com.example.demo.repo;

import com.example.demo.model.Category;
import com.example.demo.model.CustomerRentals;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "")
@RepositoryRestResource
public interface CategoryRepo extends JpaRepository<Category, Integer> {
}

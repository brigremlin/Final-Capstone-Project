package com.example.demo.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "https://video-rush-front-end.web.app/")
@RestController
public class ActorIDController {
}

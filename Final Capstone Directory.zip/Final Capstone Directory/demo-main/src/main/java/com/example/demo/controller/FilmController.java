package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.repo.FilmActorRepo;
import com.example.demo.repo.FilmRepo;
import com.example.demo.repo.InventoryRepo;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import javax.swing.text.html.Option;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "https://video-rush-front-end.web.app/")
@RestController
public class FilmController {

    @Autowired
    FilmRepo filmRepo;
    @Autowired
    InventoryRepo inventoryRepo;
    @Autowired
    FilmActorRepo filmActorRepo;

    public Film findFilmByID(Integer id) {
        List<Inventory> inventories = inventoryRepo.findAll();
        Inventory inventory = inventories.stream().filter(item -> id.equals(item.getInventory_id())).findFirst().orElse(null);
        if(inventory != null) {
            Integer inventory_id = inventory.getInventory_id();
            List<Film> films = filmRepo.findAll();
            Film film = films.stream().filter(item -> inventory_id.equals(item.getFilm_id())).findFirst().orElse(null);
            return film;
        }
        return null;
    }


    @GetMapping("/getAllFilms")
    public List<Film> getAllFilms() {
        return filmRepo.findAll();
    }

    @GetMapping("/getFilm/{id}")
    public Film getFilm(@PathVariable Integer id) {
        return this.findFilmByID(id);
    }

    @DeleteMapping("/deleteFilm/{id}")
    public void deleteFilm(@PathVariable Integer id) {
        List<FilmActor> films = this.filmActorRepo.findByIdFilmId(id);
        System.out.println(films.size());

    }
}
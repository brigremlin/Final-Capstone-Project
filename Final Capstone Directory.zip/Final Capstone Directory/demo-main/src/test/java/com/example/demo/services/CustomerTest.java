package com.example.demo.services;
import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepo;
import org.junit.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.runner.RunWith;
import static org.mockito.BDDMockito.given;

import java.util.Collections;
import java.util.List;
import java.util.Optional;


@RunWith(SpringRunner.class)
@WebMvcTest(CustomerRepo.class)
public class CustomerTest {

    @MockBean
    private CustomerRepo customerRepo;
    @Test
    public void givenCustomerList_whenGetAllCustomers_thenReturnCustomerList() throws Exception{
        short num = (short)3;
        Customer customer = new Customer(2945, num, "Timothy", "Barnes", "timothybarnes@test.com", num, true, 1);
        List customers = Collections.singletonList(customer);
        given(customerRepo.findAll()).willReturn(customers);
    }

    @Test
    public void getCustomerByID() throws Exception {
        short num = (short)3;
        Customer customer = new Customer(2945, num, "Timothy", "Barnes", "timothybarnes@test.com", num, true, 1);
        given(customerRepo.findById(customer.getCustomer_id())).willReturn(Optional.of(customer));
    }

    @Test
    public void addCustomer() throws Exception {
        short num = (short)3;
        Customer customer = new Customer(2945, num, "Timothy", "Barnes", "timothybarnes@test.com", num, true, 1);
        given(customerRepo.save(customer)).willReturn(customer);

    }
}

package com.example.demo.services;
import com.example.demo.model.Rental;
import com.example.demo.repo.RentalRepo;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.runner.RunWith;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.mockito.BDDMockito.given;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@RunWith(SpringRunner.class)
@WebMvcTest(RentalRepo.class)
public class RentalTest {

    @MockBean
    private RentalRepo rentalRepo;

    @Autowired
    private MockMvc mockMvc;
    @Test
    public void givenRentalList_whenGetAllRentals_thenReturnRentalList() throws Exception{
        short num = (short)3;
        Rental rental = new Rental(2945, new Timestamp(new java.util.Date().getTime()), 21972, num, new Timestamp(new java.util.Date().getTime()), num);
        List rentals = Collections.singletonList(rental);
        given(rentalRepo.findAll()).willReturn(rentals);
    }

    @Test
    public void getRentalByID() throws Exception {
        short num = (short)3;
        Rental rental = new Rental(2945, new Timestamp(new java.util.Date().getTime()), 21972, num, new Timestamp(new java.util.Date().getTime()), num);
        given(rentalRepo.findById(rental.getRental_id())).willReturn(Optional.of(rental));
    }
    @Test
    public void deleteRental() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders
                        .delete("/deleteRental/514")
                        .contentType(MediaType.APPLICATION_JSON));
    }

}
